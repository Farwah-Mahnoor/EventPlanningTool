import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EventForm extends JFrame {
    private JTextField titleField;
    private JTextField dateField;
    private JTextArea descriptionArea;
    private JButton saveButton;
    private EventListPanel eventListPanel;

    public EventForm(EventListPanel eventListPanel) {
        this.eventListPanel = eventListPanel;
        setTitle("Event Form");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        titleField = new JTextField(20);
        dateField = new JTextField(20);
        descriptionArea = new JTextArea(5, 20);
        saveButton = new JButton("Save");

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Title:"));
        panel.add(titleField);
        panel.add(new JLabel("Date:"));
        panel.add(dateField);
        panel.add(new JLabel("Description:"));
        panel.add(new JScrollPane(descriptionArea));
        panel.add(saveButton);

        add(panel, BorderLayout.CENTER);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String title = titleField.getText();
                String date = dateField.getText();
                String description = descriptionArea.getText();

                Event event = new Event(title, date, description);
                eventListPanel.addEvent(event);
                dispose();
            }
        });
    }
}
