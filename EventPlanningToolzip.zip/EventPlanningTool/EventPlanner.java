import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EventPlanner extends JFrame {
    private User user;
    private JButton logoutButton;

    public EventPlanner(User user) {
        this.user = user;
        setTitle("Event Planner");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        EventListPanel eventListPanel = new EventListPanel(user);
        add(eventListPanel, BorderLayout.CENTER);

        logoutButton = new JButton("Logout");
        JPanel logoutPanel = new JPanel();
        logoutPanel.add(logoutButton);
        add(logoutPanel, BorderLayout.NORTH);

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new LoginForm().setVisible(true);
                dispose();
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginForm().setVisible(true);
            }
        });
    }
}
