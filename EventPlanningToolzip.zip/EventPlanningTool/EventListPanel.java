import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class EventListPanel extends JPanel {
    private static List<Event> events = new ArrayList<>(); // Shared event list
    private DefaultListModel<Event> eventListModel;
    private JList<Event> eventList;
    private JButton addButton;
    private JButton deleteButton;
    private User user;

    public EventListPanel(User user) {
        this.user = user;
        setLayout(new BorderLayout());
        eventListModel = new DefaultListModel<>();
        eventList = new JList<>(eventListModel);
        addButton = new JButton("Add Event");
        deleteButton = new JButton("Delete Event");

        add(new JScrollPane(eventList), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        if ("manager".equals(user.getRole())) {
            buttonPanel.add(addButton);
            buttonPanel.add(deleteButton);
        }
        add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new EventForm(EventListPanel.this).setVisible(true);
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Event selectedEvent = eventList.getSelectedValue();
                if (selectedEvent != null) {
                    events.remove(selectedEvent);
                    refreshEventList();
                }
            }
        });

        refreshEventList();
    }

    public void addEvent(Event event) {
        events.add(event);
        refreshEventList();
    }

    public void refreshEventList() {
        eventListModel.clear();
        for (Event event : events) {
            eventListModel.addElement(event);
        }
    }
}
